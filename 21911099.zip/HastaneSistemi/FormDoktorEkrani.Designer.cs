﻿namespace HastaneSistemi
{
    partial class FormDoktorEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_soyad = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_ad = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label_tc = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker_yeniHasta = new System.Windows.Forms.DateTimePicker();
            this.button_NotlariKaydet = new System.Windows.Forms.Button();
            this.textBox_hasta_not = new System.Windows.Forms.TextBox();
            this.textBox_hasta_tel = new System.Windows.Forms.TextBox();
            this.textBox_hasta_soyad = new System.Windows.Forms.TextBox();
            this.textBox_hasta_ad = new System.Windows.Forms.TextBox();
            this.textBox_hasta_tc = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button_hastaTcSorgula = new System.Windows.Forms.Button();
            this.button_temizle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_soyad
            // 
            this.label_soyad.AutoSize = true;
            this.label_soyad.Location = new System.Drawing.Point(66, 77);
            this.label_soyad.Name = "label_soyad";
            this.label_soyad.Size = new System.Drawing.Size(35, 13);
            this.label_soyad.TabIndex = 1;
            this.label_soyad.Text = "label1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Soyad:";
            // 
            // label_ad
            // 
            this.label_ad.AutoSize = true;
            this.label_ad.Location = new System.Drawing.Point(66, 43);
            this.label_ad.Name = "label_ad";
            this.label_ad.Size = new System.Drawing.Size(35, 13);
            this.label_ad.TabIndex = 3;
            this.label_ad.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Ad:";
            // 
            // label_tc
            // 
            this.label_tc.AutoSize = true;
            this.label_tc.Location = new System.Drawing.Point(66, 9);
            this.label_tc.Name = "label_tc";
            this.label_tc.Size = new System.Drawing.Size(35, 13);
            this.label_tc.TabIndex = 5;
            this.label_tc.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "TC No:";
            // 
            // dateTimePicker_yeniHasta
            // 
            this.dateTimePicker_yeniHasta.Location = new System.Drawing.Point(243, 95);
            this.dateTimePicker_yeniHasta.Name = "dateTimePicker_yeniHasta";
            this.dateTimePicker_yeniHasta.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker_yeniHasta.TabIndex = 27;
            // 
            // button_NotlariKaydet
            // 
            this.button_NotlariKaydet.Location = new System.Drawing.Point(572, 220);
            this.button_NotlariKaydet.Name = "button_NotlariKaydet";
            this.button_NotlariKaydet.Size = new System.Drawing.Size(86, 63);
            this.button_NotlariKaydet.TabIndex = 26;
            this.button_NotlariKaydet.Text = "Notlari Kaydet";
            this.button_NotlariKaydet.UseVisualStyleBackColor = true;
            this.button_NotlariKaydet.Click += new System.EventHandler(this.button_NotlariKaydet_Click);
            // 
            // textBox_hasta_not
            // 
            this.textBox_hasta_not.Location = new System.Drawing.Point(243, 158);
            this.textBox_hasta_not.Multiline = true;
            this.textBox_hasta_not.Name = "textBox_hasta_not";
            this.textBox_hasta_not.Size = new System.Drawing.Size(302, 125);
            this.textBox_hasta_not.TabIndex = 23;
            // 
            // textBox_hasta_tel
            // 
            this.textBox_hasta_tel.Location = new System.Drawing.Point(243, 128);
            this.textBox_hasta_tel.Name = "textBox_hasta_tel";
            this.textBox_hasta_tel.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_tel.TabIndex = 22;
            // 
            // textBox_hasta_soyad
            // 
            this.textBox_hasta_soyad.Location = new System.Drawing.Point(243, 62);
            this.textBox_hasta_soyad.Name = "textBox_hasta_soyad";
            this.textBox_hasta_soyad.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_soyad.TabIndex = 21;
            // 
            // textBox_hasta_ad
            // 
            this.textBox_hasta_ad.Location = new System.Drawing.Point(243, 32);
            this.textBox_hasta_ad.Name = "textBox_hasta_ad";
            this.textBox_hasta_ad.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_ad.TabIndex = 20;
            // 
            // textBox_hasta_tc
            // 
            this.textBox_hasta_tc.Location = new System.Drawing.Point(243, 6);
            this.textBox_hasta_tc.Name = "textBox_hasta_tc";
            this.textBox_hasta_tc.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_tc.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(170, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Dr Notlar:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(176, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Telefon:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(149, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Doğum Tarihi:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(182, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Soyad:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(199, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Ad:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(181, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "TC No:";
            // 
            // button_hastaTcSorgula
            // 
            this.button_hastaTcSorgula.Location = new System.Drawing.Point(572, 6);
            this.button_hastaTcSorgula.Name = "button_hastaTcSorgula";
            this.button_hastaTcSorgula.Size = new System.Drawing.Size(86, 44);
            this.button_hastaTcSorgula.TabIndex = 35;
            this.button_hastaTcSorgula.Text = "TC No Sorgula";
            this.button_hastaTcSorgula.UseVisualStyleBackColor = true;
            this.button_hastaTcSorgula.Click += new System.EventHandler(this.button_hastaTcSorgula_Click);
            // 
            // button_temizle
            // 
            this.button_temizle.Location = new System.Drawing.Point(572, 60);
            this.button_temizle.Name = "button_temizle";
            this.button_temizle.Size = new System.Drawing.Size(86, 38);
            this.button_temizle.TabIndex = 36;
            this.button_temizle.Text = "Ekrani Temizle";
            this.button_temizle.UseVisualStyleBackColor = true;
            this.button_temizle.Click += new System.EventHandler(this.button_temizle_Click);
            // 
            // FormDoktorEkrani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(720, 310);
            this.Controls.Add(this.button_temizle);
            this.Controls.Add(this.button_hastaTcSorgula);
            this.Controls.Add(this.dateTimePicker_yeniHasta);
            this.Controls.Add(this.button_NotlariKaydet);
            this.Controls.Add(this.textBox_hasta_not);
            this.Controls.Add(this.textBox_hasta_tel);
            this.Controls.Add(this.textBox_hasta_soyad);
            this.Controls.Add(this.textBox_hasta_ad);
            this.Controls.Add(this.textBox_hasta_tc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label_soyad);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label_ad);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_tc);
            this.Controls.Add(this.label1);
            this.Name = "FormDoktorEkrani";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Doktor Ekrani";
            this.Load += new System.EventHandler(this.FormDoktorEkrani_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_soyad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_ad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_tc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker_yeniHasta;
        private System.Windows.Forms.Button button_NotlariKaydet;
        private System.Windows.Forms.TextBox textBox_hasta_not;
        private System.Windows.Forms.TextBox textBox_hasta_tel;
        private System.Windows.Forms.TextBox textBox_hasta_soyad;
        private System.Windows.Forms.TextBox textBox_hasta_ad;
        private System.Windows.Forms.TextBox textBox_hasta_tc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button_hastaTcSorgula;
        private System.Windows.Forms.Button button_temizle;
    }
}