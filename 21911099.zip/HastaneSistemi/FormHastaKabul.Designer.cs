﻿namespace HastaneSistemi
{
    partial class FormHastaKabul
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker_yeniHasta = new System.Windows.Forms.DateTimePicker();
            this.textBox_hasta_adres = new System.Windows.Forms.TextBox();
            this.textBox_hasta_tel = new System.Windows.Forms.TextBox();
            this.textBox_hasta_soyad = new System.Windows.Forms.TextBox();
            this.textBox_hasta_ad = new System.Windows.Forms.TextBox();
            this.textBox_hasta_tc = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_hastaTcSorgula = new System.Windows.Forms.Button();
            this.button_yeniHesap = new System.Windows.Forms.Button();
            this.button_HastaGüncelle = new System.Windows.Forms.Button();
            this.textBox_hasta_sifre = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button_temizle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dateTimePicker_yeniHasta
            // 
            this.dateTimePicker_yeniHasta.Location = new System.Drawing.Point(107, 108);
            this.dateTimePicker_yeniHasta.Name = "dateTimePicker_yeniHasta";
            this.dateTimePicker_yeniHasta.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker_yeniHasta.TabIndex = 27;
            // 
            // textBox_hasta_adres
            // 
            this.textBox_hasta_adres.Location = new System.Drawing.Point(107, 171);
            this.textBox_hasta_adres.Multiline = true;
            this.textBox_hasta_adres.Name = "textBox_hasta_adres";
            this.textBox_hasta_adres.Size = new System.Drawing.Size(302, 66);
            this.textBox_hasta_adres.TabIndex = 23;
            // 
            // textBox_hasta_tel
            // 
            this.textBox_hasta_tel.Location = new System.Drawing.Point(107, 141);
            this.textBox_hasta_tel.Name = "textBox_hasta_tel";
            this.textBox_hasta_tel.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_tel.TabIndex = 22;
            // 
            // textBox_hasta_soyad
            // 
            this.textBox_hasta_soyad.Location = new System.Drawing.Point(107, 75);
            this.textBox_hasta_soyad.Name = "textBox_hasta_soyad";
            this.textBox_hasta_soyad.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_soyad.TabIndex = 21;
            // 
            // textBox_hasta_ad
            // 
            this.textBox_hasta_ad.Location = new System.Drawing.Point(107, 45);
            this.textBox_hasta_ad.Name = "textBox_hasta_ad";
            this.textBox_hasta_ad.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_ad.TabIndex = 20;
            // 
            // textBox_hasta_tc
            // 
            this.textBox_hasta_tc.Location = new System.Drawing.Point(107, 19);
            this.textBox_hasta_tc.Name = "textBox_hasta_tc";
            this.textBox_hasta_tc.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_tc.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 178);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Adress:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Telefon:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Doğum Tarihi:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Soyad:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Ad:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "TC No:";
            // 
            // button_hastaTcSorgula
            // 
            this.button_hastaTcSorgula.Location = new System.Drawing.Point(444, 19);
            this.button_hastaTcSorgula.Name = "button_hastaTcSorgula";
            this.button_hastaTcSorgula.Size = new System.Drawing.Size(86, 44);
            this.button_hastaTcSorgula.TabIndex = 28;
            this.button_hastaTcSorgula.Text = "TC No Sorgula";
            this.button_hastaTcSorgula.UseVisualStyleBackColor = true;
            this.button_hastaTcSorgula.Click += new System.EventHandler(this.button_hastaTcSorgula_Click);
            // 
            // button_yeniHesap
            // 
            this.button_yeniHesap.Location = new System.Drawing.Point(569, 19);
            this.button_yeniHesap.Name = "button_yeniHesap";
            this.button_yeniHesap.Size = new System.Drawing.Size(86, 44);
            this.button_yeniHesap.TabIndex = 28;
            this.button_yeniHesap.Text = "Yeni Hesap Oluştur";
            this.button_yeniHesap.UseVisualStyleBackColor = true;
            this.button_yeniHesap.Click += new System.EventHandler(this.button_yeniHesap_Click);
            // 
            // button_HastaGüncelle
            // 
            this.button_HastaGüncelle.Location = new System.Drawing.Point(296, 243);
            this.button_HastaGüncelle.Name = "button_HastaGüncelle";
            this.button_HastaGüncelle.Size = new System.Drawing.Size(113, 32);
            this.button_HastaGüncelle.TabIndex = 33;
            this.button_HastaGüncelle.Text = "Güncelle";
            this.button_HastaGüncelle.UseVisualStyleBackColor = true;
            this.button_HastaGüncelle.Click += new System.EventHandler(this.button_HastaGüncelle_Click);
            // 
            // textBox_hasta_sifre
            // 
            this.textBox_hasta_sifre.Location = new System.Drawing.Point(107, 252);
            this.textBox_hasta_sifre.Name = "textBox_hasta_sifre";
            this.textBox_hasta_sifre.Size = new System.Drawing.Size(137, 20);
            this.textBox_hasta_sifre.TabIndex = 31;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(55, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 30;
            this.label7.Text = "Şifre:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(444, 72);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(211, 56);
            this.button1.TabIndex = 34;
            this.button1.Text = "Randevuları Göster";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_temizle
            // 
            this.button_temizle.Location = new System.Drawing.Point(444, 141);
            this.button_temizle.Name = "button_temizle";
            this.button_temizle.Size = new System.Drawing.Size(211, 57);
            this.button_temizle.TabIndex = 35;
            this.button_temizle.Text = "Ekrani Temizle";
            this.button_temizle.UseVisualStyleBackColor = true;
            this.button_temizle.Click += new System.EventHandler(this.button_temizle_Click);
            // 
            // FormHastaKabul
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(688, 310);
            this.Controls.Add(this.button_temizle);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_HastaGüncelle);
            this.Controls.Add(this.textBox_hasta_sifre);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button_yeniHesap);
            this.Controls.Add(this.button_hastaTcSorgula);
            this.Controls.Add(this.dateTimePicker_yeniHasta);
            this.Controls.Add(this.textBox_hasta_adres);
            this.Controls.Add(this.textBox_hasta_tel);
            this.Controls.Add(this.textBox_hasta_soyad);
            this.Controls.Add(this.textBox_hasta_ad);
            this.Controls.Add(this.textBox_hasta_tc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormHastaKabul";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hasta Kabul";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker_yeniHasta;
        private System.Windows.Forms.TextBox textBox_hasta_adres;
        private System.Windows.Forms.TextBox textBox_hasta_tel;
        private System.Windows.Forms.TextBox textBox_hasta_soyad;
        private System.Windows.Forms.TextBox textBox_hasta_ad;
        private System.Windows.Forms.TextBox textBox_hasta_tc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_hastaTcSorgula;
        private System.Windows.Forms.Button button_yeniHesap;
        private System.Windows.Forms.Button button_HastaGüncelle;
        private System.Windows.Forms.TextBox textBox_hasta_sifre;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_temizle;
    }
}