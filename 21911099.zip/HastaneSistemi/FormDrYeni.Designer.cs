﻿namespace HastaneSistemi
{
    partial class FormDrYeni
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_drKaydet = new System.Windows.Forms.Button();
            this.textBox_dr_sifre = new System.Windows.Forms.TextBox();
            this.textBox_dr_uzmanlik = new System.Windows.Forms.TextBox();
            this.textBox_dr_soyad = new System.Windows.Forms.TextBox();
            this.textBox_dr_ad = new System.Windows.Forms.TextBox();
            this.textBox_dr_tc = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_drSifre2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button_drKaydet
            // 
            this.button_drKaydet.Location = new System.Drawing.Point(300, 205);
            this.button_drKaydet.Name = "button_drKaydet";
            this.button_drKaydet.Size = new System.Drawing.Size(113, 23);
            this.button_drKaydet.TabIndex = 7;
            this.button_drKaydet.Text = "Kaydet";
            this.button_drKaydet.UseVisualStyleBackColor = true;
            this.button_drKaydet.Click += new System.EventHandler(this.button_drKaydet_Click);
            // 
            // textBox_dr_sifre
            // 
            this.textBox_dr_sifre.Location = new System.Drawing.Point(111, 175);
            this.textBox_dr_sifre.Name = "textBox_dr_sifre";
            this.textBox_dr_sifre.Size = new System.Drawing.Size(137, 20);
            this.textBox_dr_sifre.TabIndex = 5;
            // 
            // textBox_dr_uzmanlik
            // 
            this.textBox_dr_uzmanlik.Location = new System.Drawing.Point(111, 130);
            this.textBox_dr_uzmanlik.Name = "textBox_dr_uzmanlik";
            this.textBox_dr_uzmanlik.Size = new System.Drawing.Size(302, 20);
            this.textBox_dr_uzmanlik.TabIndex = 4;
            // 
            // textBox_dr_soyad
            // 
            this.textBox_dr_soyad.Location = new System.Drawing.Point(111, 91);
            this.textBox_dr_soyad.Name = "textBox_dr_soyad";
            this.textBox_dr_soyad.Size = new System.Drawing.Size(302, 20);
            this.textBox_dr_soyad.TabIndex = 3;
            // 
            // textBox_dr_ad
            // 
            this.textBox_dr_ad.Location = new System.Drawing.Point(111, 61);
            this.textBox_dr_ad.Name = "textBox_dr_ad";
            this.textBox_dr_ad.Size = new System.Drawing.Size(302, 20);
            this.textBox_dr_ad.TabIndex = 2;
            // 
            // textBox_dr_tc
            // 
            this.textBox_dr_tc.Location = new System.Drawing.Point(111, 31);
            this.textBox_dr_tc.Name = "textBox_dr_tc";
            this.textBox_dr_tc.Size = new System.Drawing.Size(302, 20);
            this.textBox_dr_tc.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(59, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Şifre:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(48, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Unvan:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Soyad:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(67, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Ad:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "TC No:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 215);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Şifre Tekrar:";
            // 
            // textBox_drSifre2
            // 
            this.textBox_drSifre2.Location = new System.Drawing.Point(111, 208);
            this.textBox_drSifre2.Name = "textBox_drSifre2";
            this.textBox_drSifre2.Size = new System.Drawing.Size(137, 20);
            this.textBox_drSifre2.TabIndex = 6;
            // 
            // FormDrYeni
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(467, 332);
            this.Controls.Add(this.button_drKaydet);
            this.Controls.Add(this.textBox_drSifre2);
            this.Controls.Add(this.textBox_dr_sifre);
            this.Controls.Add(this.textBox_dr_uzmanlik);
            this.Controls.Add(this.textBox_dr_soyad);
            this.Controls.Add(this.textBox_dr_ad);
            this.Controls.Add(this.textBox_dr_tc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormDrYeni";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Doktor Yeni Hesap Oluştur";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_drKaydet;
        private System.Windows.Forms.TextBox textBox_dr_sifre;
        private System.Windows.Forms.TextBox textBox_dr_uzmanlik;
        private System.Windows.Forms.TextBox textBox_dr_soyad;
        private System.Windows.Forms.TextBox textBox_dr_ad;
        private System.Windows.Forms.TextBox textBox_dr_tc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_drSifre2;
    }
}