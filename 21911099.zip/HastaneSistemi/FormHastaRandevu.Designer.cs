﻿namespace HastaneSistemi
{
    partial class FormHastaRandevu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_tc = new System.Windows.Forms.Label();
            this.label_ad = new System.Windows.Forms.Label();
            this.label_soyad = new System.Windows.Forms.Label();
            this.button_900 = new System.Windows.Forms.Button();
            this.button_930 = new System.Windows.Forms.Button();
            this.button_1000 = new System.Windows.Forms.Button();
            this.button_1030 = new System.Windows.Forms.Button();
            this.button1330 = new System.Windows.Forms.Button();
            this.button1300 = new System.Windows.Forms.Button();
            this.button1130 = new System.Windows.Forms.Button();
            this.button_1100 = new System.Windows.Forms.Button();
            this.button_1530 = new System.Windows.Forms.Button();
            this.button_1500 = new System.Windows.Forms.Button();
            this.button_1430 = new System.Windows.Forms.Button();
            this.button_1400 = new System.Windows.Forms.Button();
            this.button_1700 = new System.Windows.Forms.Button();
            this.button_1630 = new System.Windows.Forms.Button();
            this.button_1600 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView_hastaRandevu = new System.Windows.Forms.DataGridView();
            this.button_randevuEkle = new System.Windows.Forms.Button();
            this.button_randevuSil = new System.Windows.Forms.Button();
            this.listBox_doktorAdSoyad = new System.Windows.Forms.ListBox();
            this.listBox_bolum = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hastaRandevu)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "TC No:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ad:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Soyad:";
            // 
            // label_tc
            // 
            this.label_tc.AutoSize = true;
            this.label_tc.Location = new System.Drawing.Point(81, 24);
            this.label_tc.Name = "label_tc";
            this.label_tc.Size = new System.Drawing.Size(35, 13);
            this.label_tc.TabIndex = 0;
            this.label_tc.Text = "label1";
            // 
            // label_ad
            // 
            this.label_ad.AutoSize = true;
            this.label_ad.Location = new System.Drawing.Point(81, 58);
            this.label_ad.Name = "label_ad";
            this.label_ad.Size = new System.Drawing.Size(35, 13);
            this.label_ad.TabIndex = 0;
            this.label_ad.Text = "label1";
            // 
            // label_soyad
            // 
            this.label_soyad.AutoSize = true;
            this.label_soyad.Location = new System.Drawing.Point(81, 92);
            this.label_soyad.Name = "label_soyad";
            this.label_soyad.Size = new System.Drawing.Size(35, 13);
            this.label_soyad.TabIndex = 0;
            this.label_soyad.Text = "label1";
            // 
            // button_900
            // 
            this.button_900.Location = new System.Drawing.Point(215, 40);
            this.button_900.Name = "button_900";
            this.button_900.Size = new System.Drawing.Size(69, 35);
            this.button_900.TabIndex = 1;
            this.button_900.Text = "9:00";
            this.button_900.UseVisualStyleBackColor = true;
            this.button_900.Click += new System.EventHandler(this.button_900_Click);
            // 
            // button_930
            // 
            this.button_930.Location = new System.Drawing.Point(308, 40);
            this.button_930.Name = "button_930";
            this.button_930.Size = new System.Drawing.Size(69, 35);
            this.button_930.TabIndex = 1;
            this.button_930.Text = "9:30";
            this.button_930.UseVisualStyleBackColor = true;
            this.button_930.Click += new System.EventHandler(this.button_930_Click);
            // 
            // button_1000
            // 
            this.button_1000.Location = new System.Drawing.Point(401, 40);
            this.button_1000.Name = "button_1000";
            this.button_1000.Size = new System.Drawing.Size(69, 35);
            this.button_1000.TabIndex = 1;
            this.button_1000.Text = "10:00";
            this.button_1000.UseVisualStyleBackColor = true;
            this.button_1000.Click += new System.EventHandler(this.button_1000_Click);
            // 
            // button_1030
            // 
            this.button_1030.Location = new System.Drawing.Point(494, 40);
            this.button_1030.Name = "button_1030";
            this.button_1030.Size = new System.Drawing.Size(69, 35);
            this.button_1030.TabIndex = 1;
            this.button_1030.Text = "10:30";
            this.button_1030.UseVisualStyleBackColor = true;
            this.button_1030.Click += new System.EventHandler(this.button_1030_Click);
            // 
            // button1330
            // 
            this.button1330.Location = new System.Drawing.Point(401, 95);
            this.button1330.Name = "button1330";
            this.button1330.Size = new System.Drawing.Size(69, 35);
            this.button1330.TabIndex = 2;
            this.button1330.Text = "13:30";
            this.button1330.UseVisualStyleBackColor = true;
            this.button1330.Click += new System.EventHandler(this.button1330_Click);
            // 
            // button1300
            // 
            this.button1300.Location = new System.Drawing.Point(308, 95);
            this.button1300.Name = "button1300";
            this.button1300.Size = new System.Drawing.Size(69, 35);
            this.button1300.TabIndex = 3;
            this.button1300.Text = "13:00";
            this.button1300.UseVisualStyleBackColor = true;
            this.button1300.Click += new System.EventHandler(this.button1300_Click);
            // 
            // button1130
            // 
            this.button1130.Location = new System.Drawing.Point(215, 95);
            this.button1130.Name = "button1130";
            this.button1130.Size = new System.Drawing.Size(69, 35);
            this.button1130.TabIndex = 4;
            this.button1130.Text = "11:30";
            this.button1130.UseVisualStyleBackColor = true;
            this.button1130.Click += new System.EventHandler(this.button1130_Click);
            // 
            // button_1100
            // 
            this.button_1100.Location = new System.Drawing.Point(587, 40);
            this.button_1100.Name = "button_1100";
            this.button_1100.Size = new System.Drawing.Size(69, 35);
            this.button_1100.TabIndex = 5;
            this.button_1100.Text = "11:00";
            this.button_1100.UseVisualStyleBackColor = true;
            this.button_1100.Click += new System.EventHandler(this.button_1100_Click);
            // 
            // button_1530
            // 
            this.button_1530.Location = new System.Drawing.Point(308, 150);
            this.button_1530.Name = "button_1530";
            this.button_1530.Size = new System.Drawing.Size(69, 35);
            this.button_1530.TabIndex = 6;
            this.button_1530.Text = "15:30";
            this.button_1530.UseVisualStyleBackColor = true;
            this.button_1530.Click += new System.EventHandler(this.button_1530_Click);
            // 
            // button_1500
            // 
            this.button_1500.Location = new System.Drawing.Point(215, 150);
            this.button_1500.Name = "button_1500";
            this.button_1500.Size = new System.Drawing.Size(69, 35);
            this.button_1500.TabIndex = 7;
            this.button_1500.Text = "15:00";
            this.button_1500.UseVisualStyleBackColor = true;
            this.button_1500.Click += new System.EventHandler(this.button_1500_Click);
            // 
            // button_1430
            // 
            this.button_1430.Location = new System.Drawing.Point(587, 95);
            this.button_1430.Name = "button_1430";
            this.button_1430.Size = new System.Drawing.Size(69, 35);
            this.button_1430.TabIndex = 8;
            this.button_1430.Text = "14:30";
            this.button_1430.UseVisualStyleBackColor = true;
            this.button_1430.Click += new System.EventHandler(this.button_1430_Click);
            // 
            // button_1400
            // 
            this.button_1400.Location = new System.Drawing.Point(494, 95);
            this.button_1400.Name = "button_1400";
            this.button_1400.Size = new System.Drawing.Size(69, 35);
            this.button_1400.TabIndex = 9;
            this.button_1400.Text = "14:00";
            this.button_1400.UseVisualStyleBackColor = true;
            this.button_1400.Click += new System.EventHandler(this.button_1400_Click);
            // 
            // button_1700
            // 
            this.button_1700.Location = new System.Drawing.Point(587, 150);
            this.button_1700.Name = "button_1700";
            this.button_1700.Size = new System.Drawing.Size(69, 35);
            this.button_1700.TabIndex = 11;
            this.button_1700.Text = "17:00";
            this.button_1700.UseVisualStyleBackColor = true;
            this.button_1700.Click += new System.EventHandler(this.button_1700_Click);
            // 
            // button_1630
            // 
            this.button_1630.Location = new System.Drawing.Point(494, 150);
            this.button_1630.Name = "button_1630";
            this.button_1630.Size = new System.Drawing.Size(69, 35);
            this.button_1630.TabIndex = 12;
            this.button_1630.Text = "16:30";
            this.button_1630.UseVisualStyleBackColor = true;
            this.button_1630.Click += new System.EventHandler(this.button_1630_Click);
            // 
            // button_1600
            // 
            this.button_1600.Location = new System.Drawing.Point(401, 150);
            this.button_1600.Name = "button_1600";
            this.button_1600.Size = new System.Drawing.Size(69, 35);
            this.button_1600.TabIndex = 13;
            this.button_1600.Text = "16:00";
            this.button_1600.UseVisualStyleBackColor = true;
            this.button_1600.Click += new System.EventHandler(this.button_1600_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(215, 1);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(342, 20);
            this.dateTimePicker1.TabIndex = 14;
            // 
            // dataGridView_hastaRandevu
            // 
            this.dataGridView_hastaRandevu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_hastaRandevu.Location = new System.Drawing.Point(30, 301);
            this.dataGridView_hastaRandevu.MultiSelect = false;
            this.dataGridView_hastaRandevu.Name = "dataGridView_hastaRandevu";
            this.dataGridView_hastaRandevu.Size = new System.Drawing.Size(758, 150);
            this.dataGridView_hastaRandevu.TabIndex = 15;
            this.dataGridView_hastaRandevu.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_hastaRandevu_CellContentClick);
            this.dataGridView_hastaRandevu.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_hastaRandevu_CellContentClick);
            // 
            // button_randevuEkle
            // 
            this.button_randevuEkle.Location = new System.Drawing.Point(606, 243);
            this.button_randevuEkle.Name = "button_randevuEkle";
            this.button_randevuEkle.Size = new System.Drawing.Size(81, 47);
            this.button_randevuEkle.TabIndex = 16;
            this.button_randevuEkle.Text = "Randevu Ekle";
            this.button_randevuEkle.UseVisualStyleBackColor = true;
            this.button_randevuEkle.Click += new System.EventHandler(this.button_randevuEkle_Click);
            // 
            // button_randevuSil
            // 
            this.button_randevuSil.Location = new System.Drawing.Point(709, 243);
            this.button_randevuSil.Name = "button_randevuSil";
            this.button_randevuSil.Size = new System.Drawing.Size(79, 47);
            this.button_randevuSil.TabIndex = 16;
            this.button_randevuSil.Text = "Randevu Iptal Et";
            this.button_randevuSil.UseVisualStyleBackColor = true;
            this.button_randevuSil.Click += new System.EventHandler(this.button_randevuSil_Click);
            // 
            // listBox_doktorAdSoyad
            // 
            this.listBox_doktorAdSoyad.FormattingEnabled = true;
            this.listBox_doktorAdSoyad.Location = new System.Drawing.Point(429, 195);
            this.listBox_doktorAdSoyad.Name = "listBox_doktorAdSoyad";
            this.listBox_doktorAdSoyad.Size = new System.Drawing.Size(171, 95);
            this.listBox_doktorAdSoyad.TabIndex = 17;
            // 
            // listBox_bolum
            // 
            this.listBox_bolum.FormattingEnabled = true;
            this.listBox_bolum.Location = new System.Drawing.Point(215, 195);
            this.listBox_bolum.Name = "listBox_bolum";
            this.listBox_bolum.Size = new System.Drawing.Size(171, 95);
            this.listBox_bolum.TabIndex = 17;
            this.listBox_bolum.Click += new System.EventHandler(this.listBox_bolum_Click);
            // 
            // FormHastaRandevu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 463);
            this.Controls.Add(this.listBox_bolum);
            this.Controls.Add(this.listBox_doktorAdSoyad);
            this.Controls.Add(this.button_randevuSil);
            this.Controls.Add(this.button_randevuEkle);
            this.Controls.Add(this.dataGridView_hastaRandevu);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.button_1700);
            this.Controls.Add(this.button_1630);
            this.Controls.Add(this.button_1600);
            this.Controls.Add(this.button_1530);
            this.Controls.Add(this.button_1500);
            this.Controls.Add(this.button_1430);
            this.Controls.Add(this.button_1400);
            this.Controls.Add(this.button1330);
            this.Controls.Add(this.button1300);
            this.Controls.Add(this.button1130);
            this.Controls.Add(this.button_1100);
            this.Controls.Add(this.button_1030);
            this.Controls.Add(this.button_1000);
            this.Controls.Add(this.button_930);
            this.Controls.Add(this.button_900);
            this.Controls.Add(this.label_soyad);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label_ad);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_tc);
            this.Controls.Add(this.label1);
            this.Name = "FormHastaRandevu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormHastaRandevu";
            this.Load += new System.EventHandler(this.FormHastaRandevu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hastaRandevu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_tc;
        private System.Windows.Forms.Label label_ad;
        private System.Windows.Forms.Label label_soyad;
        private System.Windows.Forms.Button button_900;
        private System.Windows.Forms.Button button_930;
        private System.Windows.Forms.Button button_1000;
        private System.Windows.Forms.Button button_1030;
        private System.Windows.Forms.Button button1330;
        private System.Windows.Forms.Button button1300;
        private System.Windows.Forms.Button button1130;
        private System.Windows.Forms.Button button_1100;
        private System.Windows.Forms.Button button_1530;
        private System.Windows.Forms.Button button_1500;
        private System.Windows.Forms.Button button_1430;
        private System.Windows.Forms.Button button_1400;
        private System.Windows.Forms.Button button_1700;
        private System.Windows.Forms.Button button_1630;
        private System.Windows.Forms.Button button_1600;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView dataGridView_hastaRandevu;
        private System.Windows.Forms.Button button_randevuEkle;
        private System.Windows.Forms.Button button_randevuSil;
        private System.Windows.Forms.ListBox listBox_doktorAdSoyad;
        private System.Windows.Forms.ListBox listBox_bolum;
    }
}