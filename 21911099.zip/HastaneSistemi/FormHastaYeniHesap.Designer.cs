﻿namespace HastaneSistemi
{
    partial class FormHastaYeniHesap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_hasta_tc = new System.Windows.Forms.TextBox();
            this.textBox_hasta_ad = new System.Windows.Forms.TextBox();
            this.textBox_hasta_soyad = new System.Windows.Forms.TextBox();
            this.textBox_hasta_tel = new System.Windows.Forms.TextBox();
            this.textBox_hasta_adres = new System.Windows.Forms.TextBox();
            this.textBox_hasta_sifre = new System.Windows.Forms.TextBox();
            this.button_HastaKaydet = new System.Windows.Forms.Button();
            this.textBox_hastaSifre2 = new System.Windows.Forms.TextBox();
            this.dateTimePicker_yeniHasta = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "TC No:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ad:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Soyad:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Doğum Tarihi:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Telefon:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 203);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Adress:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(51, 292);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Şifre:";
            // 
            // textBox_hasta_tc
            // 
            this.textBox_hasta_tc.Location = new System.Drawing.Point(103, 44);
            this.textBox_hasta_tc.Name = "textBox_hasta_tc";
            this.textBox_hasta_tc.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_tc.TabIndex = 1;
            // 
            // textBox_hasta_ad
            // 
            this.textBox_hasta_ad.Location = new System.Drawing.Point(103, 70);
            this.textBox_hasta_ad.Name = "textBox_hasta_ad";
            this.textBox_hasta_ad.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_ad.TabIndex = 2;
            // 
            // textBox_hasta_soyad
            // 
            this.textBox_hasta_soyad.Location = new System.Drawing.Point(103, 100);
            this.textBox_hasta_soyad.Name = "textBox_hasta_soyad";
            this.textBox_hasta_soyad.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_soyad.TabIndex = 3;
            // 
            // textBox_hasta_tel
            // 
            this.textBox_hasta_tel.Location = new System.Drawing.Point(103, 166);
            this.textBox_hasta_tel.Name = "textBox_hasta_tel";
            this.textBox_hasta_tel.Size = new System.Drawing.Size(302, 20);
            this.textBox_hasta_tel.TabIndex = 5;
            // 
            // textBox_hasta_adres
            // 
            this.textBox_hasta_adres.Location = new System.Drawing.Point(103, 196);
            this.textBox_hasta_adres.Multiline = true;
            this.textBox_hasta_adres.Name = "textBox_hasta_adres";
            this.textBox_hasta_adres.Size = new System.Drawing.Size(302, 66);
            this.textBox_hasta_adres.TabIndex = 6;
            // 
            // textBox_hasta_sifre
            // 
            this.textBox_hasta_sifre.Location = new System.Drawing.Point(103, 285);
            this.textBox_hasta_sifre.Name = "textBox_hasta_sifre";
            this.textBox_hasta_sifre.Size = new System.Drawing.Size(137, 20);
            this.textBox_hasta_sifre.TabIndex = 7;
            // 
            // button_HastaKaydet
            // 
            this.button_HastaKaydet.Location = new System.Drawing.Point(292, 314);
            this.button_HastaKaydet.Name = "button_HastaKaydet";
            this.button_HastaKaydet.Size = new System.Drawing.Size(113, 23);
            this.button_HastaKaydet.TabIndex = 9;
            this.button_HastaKaydet.Text = "Kaydet";
            this.button_HastaKaydet.UseVisualStyleBackColor = true;
            this.button_HastaKaydet.Click += new System.EventHandler(this.button_HastaKaydet_Click);
            // 
            // textBox_hastaSifre2
            // 
            this.textBox_hastaSifre2.Location = new System.Drawing.Point(103, 314);
            this.textBox_hastaSifre2.Name = "textBox_hastaSifre2";
            this.textBox_hastaSifre2.Size = new System.Drawing.Size(137, 20);
            this.textBox_hastaSifre2.TabIndex = 8;
            // 
            // dateTimePicker_yeniHasta
            // 
            this.dateTimePicker_yeniHasta.Location = new System.Drawing.Point(103, 133);
            this.dateTimePicker_yeniHasta.Name = "dateTimePicker_yeniHasta";
            this.dateTimePicker_yeniHasta.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker_yeniHasta.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 319);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Şifre Tekrar:";
            // 
            // FormHastaYeniHesap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(444, 364);
            this.Controls.Add(this.dateTimePicker_yeniHasta);
            this.Controls.Add(this.button_HastaKaydet);
            this.Controls.Add(this.textBox_hastaSifre2);
            this.Controls.Add(this.textBox_hasta_sifre);
            this.Controls.Add(this.textBox_hasta_adres);
            this.Controls.Add(this.textBox_hasta_tel);
            this.Controls.Add(this.textBox_hasta_soyad);
            this.Controls.Add(this.textBox_hasta_ad);
            this.Controls.Add(this.textBox_hasta_tc);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormHastaYeniHesap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hasta Yeni Kayıt";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_hasta_tc;
        private System.Windows.Forms.TextBox textBox_hasta_ad;
        private System.Windows.Forms.TextBox textBox_hasta_soyad;
        private System.Windows.Forms.TextBox textBox_hasta_tel;
        private System.Windows.Forms.TextBox textBox_hasta_adres;
        private System.Windows.Forms.TextBox textBox_hasta_sifre;
        private System.Windows.Forms.Button button_HastaKaydet;
        private System.Windows.Forms.TextBox textBox_hastaSifre2;
        private System.Windows.Forms.DateTimePicker dateTimePicker_yeniHasta;
        private System.Windows.Forms.Label label8;
    }
}